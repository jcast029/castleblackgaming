<?php exit; ?>
1409640397
SELECT forum_id FROM bb_forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}