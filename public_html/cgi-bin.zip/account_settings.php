<?php
	require("header.html");
?>
<div id="content-container">
<div class="content-box accent" id="account_settings">
	<div id="left_settings">
		<ul>
			<li>General Settings</li>
			<li>Personal Info</li>
			<li>Account Status</li>
		</ul>
	</div>
	<div id="right_settings">
		Test
	</div>
</div>
</div>
<?php
	require("footer.html");
?>